import{test,expect} from "@playwright/test"
test("Date Pickers",async({page})=>{
    await page.goto("https://testautomationpractice.blogspot.com/")
    await page.locator('//input[@id="datepicker"]').click()
    await page.locator('//a[text()="23"]').click()
    await page.locator('//input[@id="txtDate"]').click()
    await page.locator('//select[@aria-label="Select month"]').selectOption("4")
})