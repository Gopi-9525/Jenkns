import {test,expect}from "@playwright/test"
test ("MainTask",async({page})=>{
    await page.goto("https://www.saucedemo.com/")
    await expect(page.locator('//div[text()="Swag Labs"]')).toHaveText("Swag Labs")
    await expect (page).toHaveURL("https://www.saucedemo.com/")
    await page.locator('//input[@placeholder="Username"]').fill("standard_user")
    await page.locator('//input[@placeholder="Password"]').fill("secret_sauce")
    await page.locator('//input[@id="login-button"]').click()
    await expect(page.locator('//span[text()="Products"]')).toHaveText("Products")
    await expect(page).toHaveURL("https://www.saucedemo.com/inventory.html")
    await page.locator('//select[@class="product_sort_container"]').selectOption({index:2})
   await page.locator('//button[@name="add-to-cart-sauce-labs-onesie"]').click()
   await page.locator('//button[@id="add-to-cart-sauce-labs-bolt-t-shirt"]').click()
   await page.locator('//a[@data-test="shopping-cart-link"]').click()
   
    await page.pause()
})