import {test,expect}from "@playwright/test"
test ("MainTask",async({page})=>{
    //Step1:Login
    await page.goto("https://www.saucedemo.com/")
    await expect(page.locator('//div[text()="Swag Labs"]')).toHaveText("Swag Labs")
    await expect (page).toHaveURL("https://www.saucedemo.com/")
    await page.locator('//input[@placeholder="Username"]').fill("standard_user")
    await page.locator('//input[@placeholder="Password"]').fill("secret_sauce")
    await page.locator('//input[@id="login-button"]').click()
    //Step2:Select products
    await expect(page.locator('//span[text()="Products"]')).toHaveText("Products")
    await expect(page).toHaveURL("https://www.saucedemo.com/inventory.html")
    await page.locator('//select[@class="product_sort_container"]').selectOption({index:2})
   await page.locator('//button[@name="add-to-cart-sauce-labs-onesie"]').click()
   await page.locator('//button[@id="add-to-cart-sauce-labs-bolt-t-shirt"]').click()
   await expect (page.locator('//span[text()="2"]')).toHaveText("2")
   //Step3 :Verify Shopping Cart
   await expect(page).toHaveURL("https://www.saucedemo.com/inventory.html")
   await page.locator('//a[@data-test="shopping-cart-link"]').click()
   await expect(page.locator('//span[text()="Your Cart"]')).toHaveText("Your Cart")
   await expect(page.locator('//div[text()="Sauce Labs Onesie"]')).toBeVisible()
   await expect(page.locator('//div[text()="15.99"]')).toBeVisible()
   await page.locator('//button[@id="checkout"]').click()
   //Step4:Enter Checkout
   await page.locator('//input[@id="first-name"]').fill("Gopinath")
   await page.locator('//input[@id="last-name"]').fill("N")
   await page.locator('//input[@placeholder="Zip/Postal Code"]').fill("624613")
   await page.locator('//input[@id="continue"]').click()
   await page.pause()
   await expect(page).toHaveTitle("Swag Labs")
   await expect(page.locator('//span[text()="Checkout: Your Information"]')).toContainText("Your Information")
  // await expect(page.locator(''))
   //await expect(page.locator(''))
   //await expect(page.locator(''))
   
   await page.pause()
})