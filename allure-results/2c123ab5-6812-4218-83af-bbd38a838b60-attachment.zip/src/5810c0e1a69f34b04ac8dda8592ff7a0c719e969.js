import{test,expect} from "@playwright/test"
test("Date Pickers",async({page})=>{
    await page.goto("https://testautomationpractice.blogspot.com/")
    await page.locator('//input[@id="datepicker"]').click()
})